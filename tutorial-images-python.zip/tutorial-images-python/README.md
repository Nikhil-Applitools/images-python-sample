# Applitools Tutorial - Images Python

Get started with Applitools Eyes visual testing with this basic example of using the Python and the Eyes Images SDK.

Learn more about how to install and start this project with our [Images Python tutorial](https://applitools.com/tutorials/screenshots-python.html)!

<https://applitools.com/tutorials/screenshots-python.html>

## More Information

Learn more about Applitools [Eyes](https://info.applitools.com/ucY77) and the [Ultrafast Test Cloud](https://info.applitools.com/ucY78) at [applitools.com](https://info.applitools.com/ucY76).

More about the Images Python SDK:
- https://applitools.com/docs/api/eyes-sdk/index-gen/classindex-images-python_sdk4.html
